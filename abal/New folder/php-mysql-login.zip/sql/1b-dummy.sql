INSERT INTO `users` 
(`user_name`, `user_email`, `user_password`, `user_status`) 
VALUES 
('admin', 'admin@test.com', 'e10adc3949ba59abbe56e057f20f883e', 'A');