<?php
	require_once 'php_action/db_connect.php';
	
	$id=$_GET['id'];
	
	$dat=$_POST['dat'];
	$credit=$_POST['credit'];
	
	$amount=$_POST['amount'];
	
	mysqli_query($connect,"update credit set credit_type='$credit', Date='$dat',amount=$amount where credit_id='$id'");
	header('location:credit.php');

?>