<?php
	require_once 'php_action/db_connect.php';
	$id=$_GET['id'];
	mysqli_query($connect,"delete from fixed_asset where Id='$id'");
	header('location:fixed_asset.php');

?>