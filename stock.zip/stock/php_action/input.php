<!doctype html>
<html>
<head><title>username</title></head>
<body>
<form method="POST" action="shahid.php">
	
FirstName:<input type="text" name="fname"/>
LastName:<input type="text" name="lname"/>
ss:<input type="text" class="form-control" id="date" placeholder="Date" name="date"/>

<input type="submit" value="submit"/>
</form>
</body>
</html>