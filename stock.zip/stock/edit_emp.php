<?php
	require_once 'php_action/db_connect.php';
	
	$id=$_GET['id'];
	
	
	$employee=$_POST['employee'];
	$designation=$_POST['designation'];

	$contact=$_POST['contact'];
	$salary=$_POST['salary'];
	$date=$_POST['date'];

	
	
	mysqli_query($connect,"update employee set name='$employee',desig='$designation',contact=$contact, Join_dt='$date',salary=$salary where id='$id'");
	header('location:employee.php');

?>