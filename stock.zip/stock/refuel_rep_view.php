<?php require_once 'includes/header.php'; ?>
<?php require_once 'php_action/db_connect.php';?>

<?php require_once 'php_action/core.php';?>

<?php require_once 'includes/header.php'; ?>

<?php 



if($_POST) {

	$startDate = $_POST['startDate'];
	$date = DateTime::createFromFormat('m/d/Y',$startDate);
	$start_date = $date->format("Y-m-d");


	$endDate = $_POST['endDate'];
	$format = DateTime::createFromFormat('m/d/Y',$endDate);
	$end_date = $format->format("Y-m-d");

	$sql = "SELECT  *FROM refuel WHERE date >= '$start_date' AND date <= '$end_date'";
	$query = $connect->query($sql);



	

      

	
	

	$table = '
		<table border="1" cellspacing="0" cellpadding="0" style="width:90%;">
	<tr>
		 <th style="text-align:center"> Makkah National Bricks</th>
		</tr>
	<table border="1" cellspacing="0" cellpadding="0" style="width:90%;">
	<tr>
		 <th style="text-align:center"> Refuel Report </th>
		</tr>
	
	<table border="1" cellspacing="0" cellpadding="0" style="width:90%;">
		<tr>
			<th style="text-align:center">Fuel Name</th>
			<th style="text-align:center">Quantity</th>
			
			<th style="text-align:center">Date</th>
			
			
		</tr>

		<tr>';
		
		$totalAmount = "";
		
	
		
		while ($result = $query->fetch_assoc()) {
			
			$table .= '<tr>
				
			
				
				<td><center>'.$result['Fuel_name'].'</center></td>
				<td><center>'.$result['Quantity'].'</center></td>
				
				<td><center>'.$result['Date'].'</center></td>
				
				</tr>';	
			
			
			
			  $totalAmount+=$result['Quantity'];
			
			
			
			
		
		}
		
		
		
		$table .= '
		</tr>

		
		
	<tr>
			<td colspan="3"><center>Total Quantity</center></td>
			<td><center>'.$totalAmount.'</center></td>
		</tr>

			
		
		
		
	</table>
	';	

	echo $table;
}


?>
	<!-- /col-dm-12 -->
</div>
<!-- /row -->

<script src="custom/js/gw.js"></script>

<?php require_once 'includes/footer.php'; ?>
<script src="assests/plugins/moment/moment.min.js"></script>
<script src="assests/plugins/fullcalendar/fullcalendar.min.js"></script>




<?php require_once 'includes/footer.php'; ?>
