<?php
	require_once 'php_action/db_connect.php';
	
	$id=$_GET['id'];
	
	$dat=$_POST['dat'];
	$debit=$_POST['debit'];
	
	$amount=$_POST['amount'];
	
	mysqli_query($connect,"update debit set debit_type='$debit', Date='$dat',debit_amount=$amount where debit_id='$id'");
	header('location:debit.php');

?>