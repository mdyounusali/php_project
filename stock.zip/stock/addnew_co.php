<?php
	require_once 'php_action/db_connect.php';
	
	$assetname=$_POST['assetname'];
	$dat=$_POST['dat'];
	$parts=$_POST['parts'];
	$quantity=$_POST['quantity'];
	$price=$_POST['price'];
	
	mysqli_query($connect,"insert into rep_cost (Name,Instrument,Quantity, Date,Price) values ('$assetname', '$parts', $quantity,'$dat', $price)");
	header('location:rep_cost.php');

?>