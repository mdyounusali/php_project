<?php require_once 'includes/header.php'; ?>
<?php require_once 'php_action/db_connect.php';?>


<div class="row">
	<div class="col-md-12">

		<ol class="breadcrumb">
		  <li><a href="dashboard.php">Home</a></li>		  
		  <li class="active">Account</li>
		</ol>

		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Account</div>
			</div> <!-- /panel-heading -->
			<div class="panel-body">

				<div class="remove-messages"></div>

				<div class="div-action pull pull-right" style="padding-bottom:20px;">
					<button class="btn btn-default button1" data-toggle="modal" data-target="#addBrandModel"> <i class="glyphicon glyphicon-plus-sign"></i> Debit</button>
				</div> <!-- /div-action -->				
				
				 <div class="container" id="test" style="width:100%">
 	<div class="col-md-8 col-md-offset-2">
 		 <table id="example"  class="table table-striped table-bordered table-hover">
    <thead>
        <tr> 
                <th style="text-align: center;">Debit_type</th>
			    <th style="text-align: center;">Amount</th>            
                <th style="text-align: center;">Date</th>
				<th style="text-align: center;">Action</th>
               
        </tr>
    </thead>
    <tbody>
	   
	<?php             
						$quser=mysqli_query($connect,"select * from debit");
						while($urow=mysqli_fetch_array($quser)){
							$id=$urow['debit_id'];
							?>
								<tr>
								
									<td style="text-align: center;"><?php echo $urow['debit_type']; ?></td>
									<td style="text-align: center;"><?php echo $urow['debit_amount']; ?></td>
									<td style="text-align: center;"><?php echo $urow['date']; ?></td>
									<td style="text-align: center;">

									<a href="#edit<?php echo $urow['debit_id']; ?>" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-edit"></span> Edit</a> || 
							<a href="#del<?php echo $urow['debit_id']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
							<?php include('button_deb.php'); ?>
									
									</td>
								</tr>
							<?php
						}
					
					?>    
        </tbody>
        <tfoot>
            <tr>
                <th style="text-align: center;">Debit_type</th>
			    <th style="text-align: center;">Amount</th>            
                <th style="text-align: center;">Date</th>
				<th style="text-align: center;">Action</th>
            </tr>
        </tfoot>
   </table>
 	</div>
 </div>

			</div> <!-- /panel-body -->
		</div> <!-- /panel -->		
	</div> <!-- /col-md-12 -->
</div> <!-- /row -->

<div class="modal fade" id="addBrandModel" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="submitdebitForm" action="php_action/debitaccount.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><i class="fa fa-plus"></i> Account</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="add-credit-messages"></div>
			
			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Date: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="date" placeholder="Date" name="date" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	 

	        <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Account Purpose: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="purpose" placeholder="Purpose" name="purpose" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	   

			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Amount: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="amount" placeholder="Amount" name="amount" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->				
	          	        

	      </div> <!-- /modal-body -->
	      
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="createBrandBtn" data-loading-text="Loading..." autocomplete="off">Save Changes</button>
	      </div>
	      <!-- /modal-footer -->
     	</form>
	     <!-- /.form -->
    </div>
    <!-- /modal-content -->
  </div>
  <!-- /modal-dailog -->
</div>
<!-- / add modal -->

<!-- edit brand -->
<div class="modal fade" id="editBrandModel" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="editcreditForm" action="php_action/editcredit.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><i class="fa fa-edit"></i> Edit </h4>
	      </div>
	      <div class="modal-body">

	      	<div id="edit-brand-messages"></div>

	      	<div class="modal-loading div-hide" style="width:50px; margin:auto;padding-top:50px; padding-bottom:50px;">
						<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
						<span class="sr-only">Loading...</span>
					</div>

		      <div class="edit-account-result">
		      	<div class="form-group">
		        	<label for="editdate" class="col-sm-3 control-label">Date: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <input type="text" class="form-control" id="editdate" placeholder="Date" name="editdate" autocomplete="off">
					    </div>
		        </div> <!-- /form-group-->	      


					<div class="form-group">
		        	<label for="editdate" class="col-sm-3 control-label">Account Purpose: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <input type="text" class="form-control" id="editpurpose" placeholder="Purpose" name="editpurpose" autocomplete="off">
					    </div>
		        </div> <!-- /form-group-->	 
				
				<div class="form-group">
		        	<label for="editdate" class="col-sm-3 control-label">Amout: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <input type="text" class="form-control" id="editamount" placeholder="Amount" name="" autocomplete="off">
					    </div>
		        </div> <!-- /form-group-->	 
		        
		      </div>         	        
		      <!-- /edit brand result -->

	      </div> <!-- /modal-body -->
	      
	      <div class="modal-footer editBrandFooter">
	        <button type="button" class="btn btn-default" data-dismiss="modal"> <i class="glyphicon glyphicon-remove-sign"></i> Close</button>
	        
	        <button type="submit" class="btn btn-success" id="editBrandBtn" data-loading-text="Loading..." autocomplete="off"> <i class="glyphicon glyphicon-ok-sign"></i> Save Changes</button>
	      </div>
	      <!-- /modal-footer -->
     	</form>
	     <!-- /.form -->
    </div>
    <!-- /modal-content -->
  </div>
  <!-- /modal-dailog -->
</div>
<!-- / add modal -->
<!-- /edit brand -->

<!-- remove brand -->


<script src="custom/js/debit.js"></script>
<script type="text/javascript">
    
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

<?php require_once 'includes/footer.php'; ?>