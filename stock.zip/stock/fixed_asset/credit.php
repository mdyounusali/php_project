<?php require_once 'includes/header.php'; ?>


<div class="row">
	<div class="col-md-12">

		<ol class="breadcrumb">
		  <li><a href="dashboard.php">Home</a></li>		  
		  <li class="active">Backup</li>
		</ol>

		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Data</div>
			</div> <!-- /panel-heading -->
			<div class="panel-body">

				<div class="remove-messages"></div>

				<div class="div-action pull pull-right" style="padding-bottom:20px;">
					<button class="btn btn-default button1" data-toggle="modal" data-target="#addBrandModel"> <i class="glyphicon glyphicon-plus-sign"></i> DB_Backup</button>
				</div> <!-- /div-action -->				
				
				

			</div> <!-- /panel-body -->
		</div> <!-- /panel -->		
	</div> <!-- /col-md-12 -->
</div> <!-- /row -->

<div class="modal fade" id="addBrandModel" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="submitcreditForm" action="addnew_cre.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><i class="fa fa-plus"></i> Account</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="add-credit-messages"></div>
			
			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Date: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="date" placeholder="Date" name="date" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	 

	        <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Account Purpose: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="purpose" placeholder="Purpose" name="purpose" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	   

			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Amount: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="amount" placeholder="Amount" name="amount" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->				
	          	        

	      </div> <!-- /modal-body -->
	      
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="createBrandBtn"  autocomplete="off">Backup Now</button>
	      </div>
	      <!-- /modal-footer -->
     	</form>
	     <!-- /.form -->
    </div>
    <!-- /modal-content -->
  </div>
  <!-- /modal-dailog -->
</div>
<!-- / add modal -->



<script src="custom/js/credit.js"></script>

<?php require_once 'includes/footer.php'; ?>