<?php
	require_once 'php_action/db_connect.php';
	
	$id=$_GET['id'];
	
	$dat=$_POST['dat'];
	$fue=$_POST['fuel'];
	$quantity=$_POST['quantity'];
	
	$ref=mysqli_query($connect,"select * from ua_asset where Id='".$id."'");
	$fuel=mysqli_fetch_array($ref);
	
	$temp=$fuel['Quantity']-$quantity;
	
	mysqli_query($connect,"insert into refuel (Fuel_name,Quantity, Date) values ('$fue', $quantity, '$dat')");
	mysqli_query($connect,"update ua_asset set Quantity=$temp where Id='$id'");
	header('location:use_asset.php');

?>