<?php
	require_once 'php_action/db_connect.php';
	
	
	$dat=$_POST['dat'];
	$fuel=$_POST['fuel'];
	$quantity=$_POST['quantity'];
	$price=$_POST['price'];
	
	mysqli_query($connect,"insert into ua_asset (Fuel_name,Quantity, Price,Date) values ('$fuel', $quantity, $price,'$dat')");
	header('location:use_asset.php');

?>