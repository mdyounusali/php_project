<?php
	require_once 'php_action/db_connect.php';
	
	$employee=$_POST['employee'];
	$designation=$_POST['designation'];

	$contact=$_POST['contact'];
	$salary=$_POST['salary'];
	$date=$_POST['date'];

	
	
	mysqli_query($connect,"insert into employee (name,desig, contact,salary,Join_dt) values ('$employee', '$designation',$contact,$salary,'$date')");
	header('location:employee.php');

?>