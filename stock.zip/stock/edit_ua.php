<?php
	require_once 'php_action/db_connect.php';
	
	$id=$_GET['id'];
	
	$dat=$_POST['dat'];
	$fuel=$_POST['fuel'];
	$quantity=$_POST['quantity'];
	$price=$_POST['price'];
	
	mysqli_query($connect,"update ua_asset set Fuel_name='$fuel',Quantity=$quantity, Date='$dat',Price=$price where Id='$id'");
	header('location:use_asset.php');

?>