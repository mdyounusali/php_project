<?php
	require_once 'php_action/db_connect.php';
	$id=$_GET['id'];
	mysqli_query($connect,"delete from credit where credit_id='$id'");
	header('location:credit.php');

?>