<?php
	require_once 'php_action/db_connect.php';
	
	$assetname=$_POST['assetname'];
	$dat=$_POST['dat'];
	$model=$_POST['model'];
	$quantity=$_POST['quantity'];
	$price=$_POST['price'];
	
	mysqli_query($connect,"insert into fixed_asset (Name,Model,Quantity, Date,Price) values ('$assetname', '$model', $quantity,'$dat', $price)");
	header('location:fixed_asset.php');

?>