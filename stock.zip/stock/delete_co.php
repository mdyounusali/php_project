<?php
	require_once 'php_action/db_connect.php';
	$id=$_GET['id'];
	mysqli_query($connect,"delete from rep_cost where Id='$id'");
	header('location:rep_cost.php');

?>