<?php require_once 'includes/header.php';
      require_once 'php_action/db_connect.php';
 ?>

<script src="angular.min.js"></script>
<div class="row" ng-app='myapp' ng-controller="userCtrl">
	<div class="col-md-12">

		<ol class="breadcrumb">
		  <li><a href="dashboard.php">Home</a></li>		  
		  <li class="active">HR MANAGEMENT</li>
		</ol>

		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Employee</div>
			</div> <!-- /panel-heading -->
			<div class="panel-body" >

				
				<div class="div-action pull pull-right" style="padding-bottom:20px;">
					<button type="button" class="btn btn-default button1" data-toggle="modal"  data-target="#exampleModal"> <i class="glyphicon glyphicon-plus-sign"></i> Add Employee </button>
	
                  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
<!-- Modal add -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i class="glyphicon glyphicon-plus-sign"></i>Add Employee</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="height:500px">
	  
	                   <form method="POST" action="addnew_emp.php" enctype="">
	                  

	
	               

	                     
        					<div class="form-group">
	        	<label for="date" class="col-sm-3 control-label" style="position:absolute;top:15%;left:11%"> Employee:</label> 
	        	
				    <div class="col-sm-8" style="position:absolute;top:14%;right:8%">
				      <input type="text" class="form-control"   name="employee"  >   <!-- date -->	
				    </div>
	        </div> 
			<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:31%;left:7%">Join Date: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:30%;right:8%">
						      <input  type="Date" id="startDate" name="date" class="form-control"   >
						    </div>
			        </div>
					
					<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:45%;left:4%"> Designation: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:44%;right:8%">
						      <input  type="text" class="form-control"  name="designation"  >
						    </div>
			        </div>
					<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:60%;left:9%"> Contact: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:59%;right:8%">
						      <input  type="text" class="form-control"  name="contact" ">
						    </div>
			        </div>
				
					<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:88%;left:2%">Starting Salary: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:87%;right:8%">
						      <input  type="text" class="form-control"  name="salary"  >
						    </div>
			        </div>
					
			
			
                    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		<td>&nbsp;</td>
        <input type="submit" class="btn btn-primary" value='Save' >
      </div>
      </form>
    </div>
  </div>
</div>
</div> <!-- /div-action -->			
<!-- Modal  update-->
<div class="modal fade" id="Update" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-edit"></i>Update Employee</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="height:500px">
	
	
	
	
	
	
	
	                     
        					<div class="form-group">
	        	<label for="date" class="col-sm-3 control-label" style="position:absolute;top:15%;left:11%"> Name:</label> 
	        	
				    <div class="col-sm-8" style="position:absolute;top:14%;right:8%">
				      <input type="text" class="form-control"   ng-model='name' >   <!-- date -->	
				    </div>
	        </div> 
			<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:31%;left:7%">Join Date: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:30%;right:8%">
						      <input  type="text"  id="ttt" class="form-control"  ng-model='dat' >
						    </div>
			        </div>
					<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:45%;left:4%"> Designation: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:44%;right:8%">
						      <input  type="text" class="form-control"  ng-model='deg'  >
						    </div>
			        </div>
					<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:60%;left:9%"> Contact: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:59%;right:8%">
						      <input  type="text" class="form-control"   ng-model='con' ">
						    </div>
			        </div>
					<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:74%;left:5%"> Department: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:73%;right:8%">
						      <input  type="text" class="form-control"  ng-model='dep'>
						    </div>
			        </div>
					<div class="form-group">
			        	<label for="editProductName" class="col-sm-3 control-label"style="position:absolute;top:88%;left:2%">Starting Salary: </label>
			        	
						    <div class="col-sm-8" style="position:absolute;top:87%;right:8%">
						      <input  type="text" class="form-control"  ng-model='sal'  >
						    </div>
			        </div>
					
			
			
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		<td>&nbsp;</td>
        <input type="button" class="btn btn-primary"id='but_save' value='Update' ng-click="add()">
      </div>
    </div>
  </div>
</div>
</div> <!-- /div-action -->			
				
				
				<!-- /table -->
				 <div class="container" id="test" style="width:100%">
 	<div class="col-md-8 col-md-offset-2">
 		 <table id="example"  class="table table-striped table-bordered table-hover">
    <thead>
        <tr> 
                <th style="text-align: center;">Employee</th>
			    <th style="text-align: center;">Designation</th>            
                <th style="text-align: center;">Contact</th>
               
			    <th style="text-align: center;">Salary</th>            
                <th style="text-align: center;">Join Date</th>
				<th style="text-align: center;">Action</th>
               
        </tr>
    </thead>
    <tbody>
	   
	<?php             
						$quser=mysqli_query($connect,"select * from employee");
						while($urow=mysqli_fetch_array($quser)){
							$id=$urow['id'];
							?>
								<tr>
								
									<td style="text-align: center;"><?php echo $urow['name']; ?></td>
									<td style="text-align: center;"><?php echo $urow['desig']; ?></td>
									<td style="text-align: center;"><?php echo $urow['contact']; ?></td>
									
									<td style="text-align: center;"><?php echo $urow['salary']; ?></td>
									<td style="text-align: center;"><?php echo $urow['Join_dt']; ?></td>
									<td style="text-align: center;">

									<a href="#edit<?php echo $urow['id']; ?>" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-edit"></span> Edit</a> || 
							<a href="#del<?php echo $urow['id']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
							<?php include('button_emp.php'); ?>
									
									</td>
								</tr>
							<?php
						}
					
					?>    
        </tbody>
        <tfoot>
            <tr>
                <th style="text-align: center;">Employee</th>
			    <th style="text-align: center;">Designation</th>            
                <th style="text-align: center;">Contact</th>
               
			    <th style="text-align: center;">Salary</th>            
                <th style="text-align: center;">Join Date</th>
				<th style="text-align: center;">Action</th>

            </tr>
        </tfoot>
   </table>
 	</div>
 </div>
				
			</div> <!-- /panel-body -->
		</div> <!-- /panel -->		
	</div> <!-- /col-md-12 -->
</div> <!-- /row -->

<script src="jquery-3.4.1.min.js"></script>
<script type="text/javascript">
    
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>


<?php require_once 'includes/footer.php'; ?>