<?php 
     require_once 'includes/header.php'; 
     require_once 'php_action/db_connect.php';
	 
?>


<div class="row">
	<div class="col-md-12">

		<ol class="breadcrumb">
		  <li><a href="dashboard.php">Home</a></li>		  
		  <li class="active">Asset</li>
		</ol>

		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Asset</div>
			</div> <!-- /panel-heading -->
			<div class="panel-body">

				<div class="remove-messages"></div>

				<div class="div-action pull pull-right" style="padding-bottom:20px;">
					<button class="btn btn-default button1" data-toggle="modal" data-target="#addBrandModel"> <i class="glyphicon glyphicon-plus-sign"></i> Fixed Asset</button>
				</div> <!-- /div-action -->				
				
				

			</div> <!-- /panel-body -->
			<!-- here is the table area -->
			
		 <div class="container" id="test" style="width:100%">
 	<div class="col-md-8 col-md-offset-2">
 		 <table id="example"  class="table table-striped table-bordered table-hover">
    <thead>
        <tr> 
                <th style="text-align: center;">Asset Name</th>
                <th style="text-align: center;">Model</th>            
                <th style="text-align: center;">Quantity</th>
			    <th style="text-align: center;">Price</th>            
                <th style="text-align: center;">Date</th>
				<th style="text-align: center;">Action</th>
               
        </tr>
    </thead>
    <tbody>
	   
	<?php             
						$quser=mysqli_query($connect,"select * from fixed_asset");
						while($urow=mysqli_fetch_array($quser)){
							$id=$urow['Id'];
							?>
								<tr>
								
									<td style="text-align: center;"><?php echo $urow['Name']; ?></td>
									<td style="text-align: center;"><?php echo $urow['Model']; ?></td>
									<td style="text-align: center;"><?php echo $urow['Quantity']; ?></td>
									<td style="text-align: center;"><?php echo $urow['Price']; ?></td>
									<td style="text-align: center;"><?php echo $urow['Date']; ?></td>
									<td style="text-align: center;">

									<a href="#edit<?php echo $urow['Id']; ?>" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-edit"></span> Edit</a> || 
							<a href="#del<?php echo $urow['Id']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
							<?php include('button_fa.php'); ?>
									
									</td>
								</tr>
							<?php
						}
					
					?>    
        </tbody>
        <tfoot>
            <tr>
                <th style="text-align: center;">Asset Name</th>
                <th style="text-align: center;">Model</th>            
                <th style="text-align: center;">Quantity</th>
			    <th style="text-align: center;">Price</th>            
                <th style="text-align: center;">Date</th>
                <th style="text-align: center;">Action</th>
            </tr>
        </tfoot>
   </table>
 	</div>
 </div>
			
			<!-- here is the table area -->
		</div> <!-- /panel -->		
	</div> <!-- /col-md-12 -->
 <!-- /row -->

<div class="modal fade" id="addBrandModel" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="submitdebitForm" action="addnew_fa.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><i class="fa fa-plus"></i> Add Asset</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="add-credit-messages"></div>
			
			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Date: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="date" class="form-control"  placeholder="Date" name="dat" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	 

	        <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Asset Name: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="name" placeholder="Name" name="assetname" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	   
        <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Model: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="model" placeholder="model" name="model" autocomplete="off">
				    </div>
	        </div> 
              
			  <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Quantity: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="quantity" placeholder="quantity" name="quantity" autocomplete="off">
				    </div>
	        </div>
			  
			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Price: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="amount" placeholder="price" name="price" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->				
	          	          

	      </div> <!-- /modal-body -->
	      
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="createBrandBtn" data-loading-text="Loading..." autocomplete="off">Save Changes</button>
	      </div>
	      <!-- /modal-footer -->
     	</form>
	     <!-- /.form -->
    </div>
    <!-- /modal-content -->
  </div>
  <!-- /modal-dailog -->
</div>
<!-- / add modal -->

<!-- edit brand -->

<script src="custom/js/creditreport.js"></script>
<script type="text/javascript">
    $("#time").datepicker();
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>





<?php require_once 'includes/footer.php'; ?>