<?php 
     require_once 'includes/header.php'; 
    // require_once 'php_action/db_connect.php';
    // require_once 'php_action/index.php';
	 
?>

<!-- Delete -->
    <div class="modal fade" id="del<?php echo $urow['Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Delete</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$del=mysqli_query($connect,"select * from fixed_asset where Id='".$urow['Id']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5><center>Firstname: <strong><?php echo $urow['Name']; ?></strong></center></h5> 
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="delete_fa.php?id=<?php echo $urow['Id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Edit -->
    <div class="modal fade" id="edit<?php echo $urow['Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-plus"></i> Update Asset</h4>
                </div>
                <div class="modal-body">
				<?php
					$edit=mysqli_query($connect,"select * from fixed_asset where Id='".$urow['Id']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="edit_fa.php?id=<?php echo $erow['Id']; ?>">
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">AssetName:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="assetname" class="form-control" value="<?php echo $erow['Name']; ?>">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Date:</label>
						</div>
						<div class="col-lg-10">
							<input type="Date" name="dat" id="startDate" class="form-control" value="<?php echo $erow['Date']; ?>">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Model:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="model" class="form-control" value="<?php echo $erow['Model']; ?>">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Quantity:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="quantity" class="form-control" value="<?php echo $erow['Quantity']; ?>">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Price:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="price" class="form-control" value="<?php echo $erow['Price']; ?>">
						</div>
					</div>
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->

<script src="custom/js/creditreport.js"></script>

<?php require_once 'includes/footer.php'; ?>