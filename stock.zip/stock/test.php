<?php
include 'fixed_asset.php';

echo $a;






?>