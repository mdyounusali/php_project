<?php
	require_once 'php_action/db_connect.php';
	
	$purpose=$_POST['purpose'];
	$date=$_POST['date'];

	$amount=$_POST['amount'];
	
	mysqli_query($connect,"insert into credit (credit_type,amount, date) values ('$purpose', $amount,'$date')");
	header('location:credit.php');

?>