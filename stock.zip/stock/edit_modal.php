<?php 
     require_once 'includes/header.php'; 
     require_once 'php_action/db_connect.php';
?>
<div class="modal fade" id="edit" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="submitdebitForm" action="php_action/debitaccount.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><i class="fa fa-plus"></i> Account</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="add-credit-messages"></div>
			
			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Date: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="date" placeholder="Date" name="date" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	 

	        <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Name: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="name" placeholder="Name" name="name" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->	   
        <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Model: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="model" placeholder="model" name="model" autocomplete="off">
				    </div>
	        </div> 
              
			  <div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Quantity: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="quantity" placeholder="quantity" name="quantity" autocomplete="off">
				    </div>
	        </div>
			  
			<div class="form-group">
	        	<label for="brandName" class="col-sm-3 control-label">Amount: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="amount" placeholder="Amount" name="amount" autocomplete="off">
				    </div>
	        </div> <!-- /form-group-->				
	          	          

	      </div> <!-- /modal-body -->
	      
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="createBrandBtn" data-loading-text="Loading..." autocomplete="off">Save Changes</button>
	      </div>
	      <!-- /modal-footer -->
     	</form>
	     <!-- /.form -->
    </div>
    <!-- /modal-content -->
  </div>
  <!-- /modal-dailog -->
</div>